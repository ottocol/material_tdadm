//
//  MMConversor.m
//  Comunicacion
//
//  Created by Otto Colomina Pardo on 08/07/14.
//  Copyright (c) 2014 Otto Colomina Pardo. All rights reserved.
//

#import "ConversorEUR_USD.h"

@implementation ConversorEUR_USD {
    NSTimer *miTimer;
}

- (id)init {
    self = [super init];
    self.unEuroEnUSD = 1.0;
    //el tipo de cambio se actualiza cada 5 segundos
    miTimer = [NSTimer scheduledTimerWithTimeInterval:5
                                     target:self
                                   selector:@selector(actualizarTipoDeCambio) userInfo:nil repeats:YES];
    
    return self;
}

- (CGFloat) cuantosEURsonUSD:(CGFloat)usd {
    return usd/self.unEuroEnUSD;
}

- (CGFloat) cuantosUSDsonEUR:(CGFloat)euros {
    return euros*self.unEuroEnUSD;
}


-(void) actualizarTipoDeCambio {
    //el tipo de cambio habría que consultarlo a algún servidor, como es una prueba se genera al azar
    self.unEuroEnUSD = (100.0+arc4random()%50)/100.0;
    NSLog(@"Cambio actual: %f", self.unEuroEnUSD);
}

-(void) dealloc {
    NSLog(@"Invalidando timer...");
    [miTimer invalidate];
}
@end
