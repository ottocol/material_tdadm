//
//  MMAppDelegate.h
//  Comunicacion
//
//  Created by Otto Colomina Pardo on 02/07/14.
//  Copyright (c) 2014 Otto Colomina Pardo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
