//
//  MMConversor.h
//  Comunicacion
//
//  Created by Otto Colomina Pardo on 08/07/14.
//  Copyright (c) 2014 Otto Colomina Pardo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ConversorEUR_USD : NSObject
@property CGFloat unEuroEnUSD;
- (id) init;
- (CGFloat) cuantosUSDsonEUR:(CGFloat)euros;
- (CGFloat) cuantosEURsonUSD:(CGFloat)usd;
- (void) actualizarTipoDeCambio;
- (void) dealloc;
@end
