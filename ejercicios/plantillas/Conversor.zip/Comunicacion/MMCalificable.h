//
//  MMCalificable.h
//  Comunicacion
//
//  Created by Otto Colomina Pardo on 04/07/14.
//  Copyright (c) 2014 Otto Colomina Pardo. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MMCalificable
- (void) setNota: (CGFloat) nota hacia:(NSInteger) redondeo;
- (CGFloat) nota;

@end
