//
//  MMPrueba.h
//  Comunicacion
//
//  Created by Otto Colomina Pardo on 04/07/14.
//  Copyright (c) 2014 Otto Colomina Pardo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMCalificable.h"

@interface MMPrueba : NSObject<MMCalificable>

@end
