//
//  MMViewController.m
//  Comunicacion
//
//  Created by Otto Colomina Pardo on 02/07/14.
//  Copyright (c) 2014 Otto Colomina Pardo. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "ConversorEUR_USD.h"

@interface ViewController ()

@end

@implementation ViewController

ConversorEUR_USD *conversor;


- (void)viewDidLoad
{
    [super viewDidLoad];
	
    conversor = [[ConversorEUR_USD alloc] init];

    self.tipoCambioLabel.text = [NSString stringWithFormat:@"1 € = %1.3f $",
                                 conversor.unEuroEnUSD];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)obtenerEurosPulsado:(id)sender {
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    numberFormatter.numberStyle = NSNumberFormatterDecimalStyle;
    CGFloat dolares = [numberFormatter numberFromString:self.cantidadDolares.text].floatValue;
    CGFloat euros =[conversor cuantosEURsonUSD:dolares];
    self.cantidadEuros.text = [NSString stringWithFormat:@"%1.3f", euros];
}

- (IBAction)obtenerDolaresPulsado:(id)sender {
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    numberFormatter.numberStyle = NSNumberFormatterDecimalStyle;
    CGFloat euros = [numberFormatter numberFromString:self.cantidadEuros.text].floatValue;
    CGFloat dolares =[conversor cuantosUSDsonEUR:euros];
    self.cantidadDolares.text = [NSString stringWithFormat:@"%1.3f", dolares];
}


@end
